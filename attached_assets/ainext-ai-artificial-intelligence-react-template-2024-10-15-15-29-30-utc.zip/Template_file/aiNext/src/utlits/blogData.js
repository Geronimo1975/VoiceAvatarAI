import img_1 from "../assets/img/blogs/artical-1.jpg"
import img_2 from "../assets/img/blogs/artical-2.jpg"
import img_3 from "../assets/img/blogs/artical-3.jpg"
import img_4 from "../assets/img/blogs/artical-4.jpg"

export const blogData = [
    {
        id: "1",
        thumb: img_1,
        title: "The actual history of machine intelligence",
        desc: "",
        date: "March 18, 2022",
        author: "",
        link: "/blog-details"
    },
    {
        id: "2",
        thumb: img_2,
        title: "The actual history of machine intelligence",
        desc: "",
        date: "March 18, 2022",
        author: "",
        link: "/blog-details"
    },
    {
        id: "3",
        thumb: img_3,
        title: "The actual history of machine intelligence",
        desc: "",
        date: "March 18, 2022",
        author: "",
        link: "/blog-details"
    },
    {
        id: "4",
        thumb: img_4,
        title: "The actual history of machine intelligence",
        desc: "",
        date: "March 18, 2022",
        author: "",
        link: "/blog-details"
    },
    {
        id: "5",
        thumb: img_1,
        title: "The actual history of machine intelligence",
        desc: "",
        date: "March 18, 2022",
        author: "",
        link: "/blog-details"
    },
    {
        id: "6",
        thumb: img_2,
        title: "The actual history of machine intelligence",
        desc: "",
        date: "March 18, 2022",
        author: "",
        link: "/blog-details"
    },
]